#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

string toLowerStr(const string &s) {
    string r = s;
    for (size_t i = 0; i < r.size(); ++i) r[i] = static_cast<char>(tolower(r[i]));
    return r;
}

bool isNumberString(const string &s) {
    bool hasDigit = false;
    bool hasDot = false;
    for (char c : s) {
        if (isdigit(static_cast<unsigned char>(c))) hasDigit = true;
        else if (c == '.' && !hasDot) hasDot = true;
        else return false;
    }
    return hasDigit;
}

double getDoubleInput(const string &prompt) {
    while (true) {
        cout << prompt;
        string line;
        getline(cin, line);
        if (line.empty()) continue;
        if (isNumberString(line)) {
            try {
                double val = stod(line);
                return val;
            } catch (...) {
                cout << "Invalid number format. Try again.\n";
            }
        } else {
            cout << "Invalid number. Try again.\n";
        }
    }
}

int getIntInput(const string &prompt) {
    while (true) {
        cout << prompt;
        string line;
        getline(cin, line);
        if (line.empty()) continue;
        bool ok = true;
        size_t i = 0;
        if (line[0] == '-') i = 1;
        for (; i < line.size(); ++i) if (!isdigit(static_cast<unsigned char>(line[i]))) { ok = false; break; }
        if (ok) {
            try {
                int v = stoi(line);
                return v;
            } catch (...) {
                cout << "Invalid integer. Try again.\n";
            }
        } else {
            cout << "Invalid integer. Try again.\n";
        }
    }
}

string getLineInputNonEmpty(const string &prompt) {
    while (true) {
        cout << prompt;
        string line;
        getline(cin, line);
        if (!line.empty()) return line;
        cout << "Input cannot be empty. Try again.\n";
    }
}

