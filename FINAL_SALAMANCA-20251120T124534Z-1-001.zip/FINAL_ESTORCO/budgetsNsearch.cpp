#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

void addBudgetInteractive(const string &owner) {
    if (budgetCount >= MAX_BUDGETS) { cout << "Budget storage full.\n"; return; }
    Budget b;
    b.id = nextBudgetId++;
    cout << "Enter record name: ";
    getline(cin, b.name);
    b.amount = getDoubleInput("Enter amount: ");
    cout << "Enter type (Income/Expense): ";
    string t;
    getline(cin, t);
    while (toLowerStr(t) != "income" && toLowerStr(t) != "expense") {
        cout << "Type must be Income or Expense. Enter again: ";
        getline(cin, t);
    }
    b.type = t;
    b.owner = owner;
    budgets[budgetCount++] = b;
    saveBudgetsToFile();
    cout << "Record added.\n";
}

int findBudgetIndexById(int id) {
    for (int i = 0; i < budgetCount; ++i) if (budgets[i].id == id) return i;
    return -1;
}

void editBudgetInteractive(const string &currentUser, bool isParentOrAdult) {
    if (budgetCount == 0) { cout << "No budgets to edit.\n"; return; }
    int id = getIntInput("Enter budget ID to edit: ");
    int idx = findBudgetIndexById(id);
    if (idx < 0) { cout << "Budget not found.\n"; return; }
    if (!isParentOrAdult && toLowerStr(budgets[idx].owner) != toLowerStr(currentUser)) { cout << "You can only edit your own records.\n"; return; }
    cout << "Current name: " << budgets[idx].name << "\n";
    cout << "Enter new name (or leave blank to keep): ";
    string temp;
    getline(cin, temp);
    if (!temp.empty()) budgets[idx].name = temp;
    cout << "Current amount: " << budgets[idx].amount << "\n";
    cout << "Enter new amount (or leave blank to keep): ";
    string amtLine;
    getline(cin, amtLine);
    if (!amtLine.empty()) {
        while (!isNumberString(amtLine)) { cout << "Invalid number. Enter again: "; getline(cin, amtLine); }
        budgets[idx].amount = stod(amtLine);
    }
    cout << "Current type: " << budgets[idx].type << "\n";
    cout << "Enter new type (Income/Expense) (or leave blank to keep): ";
    string newType;
    getline(cin, newType);
    if (!newType.empty()) {
        while (toLowerStr(newType) != "income" && toLowerStr(newType) != "expense") { cout << "Type must be Income or Expense. Enter again: "; getline(cin, newType); }
        budgets[idx].type = newType;
    }
    saveBudgetsToFile();
    cout << "Budget updated.\n";
}

void deleteBudgetInteractive(const string &currentUser, bool isParentOrAdult) {
    if (budgetCount == 0) { cout << "No budgets to delete.\n"; return; }
    int id = getIntInput("Enter budget ID to delete: ");
    int idx = findBudgetIndexById(id);
    if (idx < 0) { cout << "Budget not found.\n"; return; }
    if (!isParentOrAdult && toLowerStr(budgets[idx].owner) != toLowerStr(currentUser)) { cout << "You can only delete your own records.\n"; return; }
    for (int i = idx; i < budgetCount - 1; ++i) budgets[i] = budgets[i + 1];
    --budgetCount;
    saveBudgetsToFile();
    cout << "Budget deleted.\n";
}

void searchBudgetsMenu() {
    cout << "Search by: 1) Name 2) Type 3) Owner 4) Amount range\n";
    int ch = getIntInput("Choice: ");
    if (ch == 1) {
        string key = getLineInputNonEmpty("Enter name keyword: ");
        bool found = false;
        for (int i = 0; i < budgetCount; ++i) if (toLowerStr(budgets[i].name).find(toLowerStr(key)) != string::npos) {
            if (!found) { cout << setw(5) << "ID" << setw(30) << "Name" << setw(12) << "Amount" << setw(12) << "Type" << setw(18) << "Owner" << endl; cout << string(80, '-') << endl; }
            found = true;
            cout << setw(5) << budgets[i].id << setw(30) << budgets[i].name << setw(12) << fixed << setprecision(2) << budgets[i].amount << setw(12) << budgets[i].type << setw(18) << budgets[i].owner << endl;
        }
        if (!found) cout << "No matches.\n";
    } else if (ch == 2) {
        string type = getLineInputNonEmpty("Enter type (Income/Expense): ");
        bool found = false;
        for (int i = 0; i < budgetCount; ++i) if (toLowerStr(budgets[i].type) == toLowerStr(type)) {
            if (!found) { cout << setw(5) << "ID" << setw(30) << "Name" << setw(12) << "Amount" << setw(12) << "Type" << setw(18) << "Owner" << endl; cout << string(80, '-') << endl; }
            found = true;
            cout << setw(5) << budgets[i].id << setw(30) << budgets[i].name << setw(12) << fixed << setprecision(2) << budgets[i].amount << setw(12) << budgets[i].type << setw(18) << budgets[i].owner << endl;
        }
        if (!found) cout << "No matches.\n";
    } else if (ch == 3) {
        string owner = getLineInputNonEmpty("Enter owner username: ");
        bool found = false;
        for (int i = 0; i < budgetCount; ++i) if (toLowerStr(budgets[i].owner) == toLowerStr(owner)) {
            if (!found) { cout << setw(5) << "ID" << setw(30) << "Name" << setw(12) << "Amount" << setw(12) << "Type" << setw(18) << "Owner" << endl; cout << string(80, '-') << endl; }
            found = true;
            cout << setw(5) << budgets[i].id << setw(30) << budgets[i].name << setw(12) << fixed << setprecision(2) << budgets[i].amount << setw(12) << budgets[i].type << setw(18) << budgets[i].owner << endl;
        }
        if (!found) cout << "No matches.\n";
    } else if (ch == 4) {
        double low = getDoubleInput("Enter low: ");
        double high = getDoubleInput("Enter high: ");
        bool found = false;
        for (int i = 0; i < budgetCount; ++i) if (budgets[i].amount >= low && budgets[i].amount <= high) {
            if (!found) { cout << setw(5) << "ID" << setw(30) << "Name" << setw(12) << "Amount" << setw(12) << "Type" << setw(18) << "Owner" << endl; cout << string(80, '-') << endl; }
            found = true;
            cout << setw(5) << budgets[i].id << setw(30) << budgets[i].name << setw(12) << fixed << setprecision(2) << budgets[i].amount << setw(12) << budgets[i].type << setw(18) << budgets[i].owner << endl;
        }
        if (!found) cout << "No matches.\n";
    } else cout << "Invalid choice.\n";
}

